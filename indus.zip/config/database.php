<?php
if (!function_exists('writeSimpleLog')) {
    function writeSimpleLog($message, $context = []) {
        static $hasLoggedThisRequest = false;

        if ($hasLoggedThisRequest && empty($context)) {
            return;
        }

        $logDir = __DIR__ . '/../logs';
        if (!is_dir($logDir)) {
            @mkdir($logDir, 0775, true);
        }

        $logFile = $logDir . '/log.txt';
        $timestamp = date('Y-m-d H:i:s');
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $uri = $_SERVER['REQUEST_URI'] ?? 'cli';
        $method = $_SERVER['REQUEST_METHOD'] ?? 'CLI';

        $line = $timestamp . ' | [' . $method . '] | ' . $ip . ' | ' . $uri . ' | ' . $message;
        if (!empty($context)) {
            $line .= ' | ' . json_encode($context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        }

        @file_put_contents($logFile, $line . PHP_EOL, FILE_APPEND | LOCK_EX);
        $hasLoggedThisRequest = true;
    }
}

function getDatabaseConnection() {
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $host = 'localhost';
    $dbname = 'shipment_tracking';
    $username = 'root';
    $password = '';

    try {
        $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);

        return $pdo;
    } catch (PDOException $e) {
        writeSimpleLog('Database connection failed', ['error' => $e->getMessage()]);
        throw $e;
    }
}

global $pdo;

try {
    $pdo = getDatabaseConnection();
    writeSimpleLog('Database connection established successfully');

    try {
        $stmt = $pdo->prepare("SHOW COLUMNS FROM shipment_parties LIKE 'destination_agent_email'");
        $stmt->execute();
        if (!$stmt->fetch()) {
            $pdo->exec("ALTER TABLE shipment_parties ADD COLUMN destination_agent_email VARCHAR(255) DEFAULT NULL");
            writeSimpleLog('Added missing shipment_parties.destination_agent_email column');
        }
    } catch (PDOException $schemaException) {
        writeSimpleLog('Schema check skipped/failed for shipment_parties', ['error' => $schemaException->getMessage()]);
    }
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

writeSimpleLog('Application session initialized');
